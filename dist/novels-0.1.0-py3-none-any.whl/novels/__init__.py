default_app_config = "novels.apps.NovelsConfig"
APP_NAME = "novels"
