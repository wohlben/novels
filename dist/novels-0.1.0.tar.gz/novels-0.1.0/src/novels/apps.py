from django.apps import AppConfig


class NovelsConfig(AppConfig):
    name = "novels"
